package com.blog.blog.model;

public enum UserType {
    USER,AUTHOR
}
