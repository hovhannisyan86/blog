package com.blog.blog.controller;

import com.blog.blog.model.Article;
import com.blog.blog.model.Category;
import com.blog.blog.model.User;
import com.blog.blog.repository.ArticleRepository;
import com.blog.blog.repository.CategoryRepository;
import com.blog.blog.repository.UserRepository;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

@Controller
public class MainController{

    @Value("${springdemo.user.pic.url}/")
    private String userPicDir;

    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ArticleRepository articleRepository;

    @GetMapping("/")
    public String index(ModelMap modelMap){
        List<Article> articleList = articleRepository.findAll();
        modelMap.addAttribute("articles", articleList);
        return "index";
    }

    @GetMapping("/admin")
    public String admin(ModelMap modelMap){
        List<Category> categoryList = categoryRepository.findAll();
        modelMap.addAttribute("categories", categoryList);
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String authName = auth.getName();
        Optional<User> byEmail = userRepository.findByEmail(authName);
        if(byEmail.isPresent()){
            modelMap.addAttribute("loggedUser", byEmail.get());
        }
        return "admin";
    }

    @GetMapping(value = "/articleImage")
    public @ResponseBody
    byte[] userImage(@RequestParam("picUrl") String picUrl) throws IOException {
        InputStream in = new FileInputStream(userPicDir + picUrl);
        return IOUtils.toByteArray(in);
    }

}
