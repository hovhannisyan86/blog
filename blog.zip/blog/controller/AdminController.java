package com.blog.blog.controller;

import com.blog.blog.model.Article;
import com.blog.blog.model.Category;
import com.blog.blog.model.User;
import com.blog.blog.repository.ArticleRepository;
import com.blog.blog.repository.CategoryRepository;
import com.blog.blog.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Value("${springdemo.user.pic.url}")
    private String userPicDir;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ArticleRepository articleRepository;

    @PostMapping("/addCat")
    public String addCat(@ModelAttribute Category category){
        if(!category.getName().equals("")){
            categoryRepository.save(category);
        }
        return "redirect:/admin";
    }

    @PostMapping("/addUser")
    public String addUser(@ModelAttribute User user, @RequestParam("pic") MultipartFile multipartFile){
        if(!user.getName().equals("")){
            File dir = new File(userPicDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            String picName = System.currentTimeMillis() + "_" + multipartFile.getOriginalFilename();
            try {
                multipartFile.transferTo(new File(dir, picName));
            } catch (IOException e) {
                e.printStackTrace();
            }
            user.setImage(picName);
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            userRepository.save(user);
        }
        return "redirect:/admin";
    }

    @PostMapping("/addArticle")
    public String addUser(@ModelAttribute Article article, @RequestParam("articleImage") MultipartFile multipartFile){
        if(!article.getTitle().equals("")){
            File dir = new File(userPicDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            String picName = System.currentTimeMillis() + "_" + multipartFile.getOriginalFilename();
            try {
                multipartFile.transferTo(new File(dir, picName));
            } catch (IOException e) {
                e.printStackTrace();
            }
            article.setImage(picName);

            articleRepository.save(article);
        }
        return "redirect:/admin";
    }
}
